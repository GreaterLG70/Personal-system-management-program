#!/bin/bash
echo "启动 PRTS 系统工具箱..."
./PRTS
